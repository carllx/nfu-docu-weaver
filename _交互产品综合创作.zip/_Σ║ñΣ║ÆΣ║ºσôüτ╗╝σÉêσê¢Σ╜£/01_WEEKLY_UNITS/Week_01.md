---
week_num: 1
epic: "塑造二维平面"
title: "学习基础，完成首个线框图"
learning_objectives:
  - "学生能独立使用画框、形状、文本工具。"
  - "学生能填写一份项目简报。"
  - "学生能制作一个至少3页的低保真线框图。"
assessment:
  type: "课堂项目"
  criteria: "完成 Class Project 02 - Wireframe"
content_status: "outline-complete"
related_slide: "02_SLIDES/Week_01.marpit.md"
version: "1.0"
teacher_notes: "本周重点是消除学生对Figma的陌生感，建立UI/UX基本认知，并完成第一个可交付的线框图作业。核心是动手操作，而不是理论。"
---

# Week 01: 学习基础，完成首个线框图

## 📚 本周目标 (Overall Goal)

在本周结束时，学生应能完全掌握Figma的基础操作，理解UI与UX的核心区别，并独立完成一份从项目简报到低保真线框图的完整初始设计流程。

---

## 核心概念 (Concepts)

- **UI vs UX 的区别** (源: `004.md`)
- **Lo-Fi vs Hi-Fi 的概念** (源: `007.md`)
- **Frames vs Groups 的核心差异** (源: `015.md`)

---

## 核心技能演示与实操 (Demo & Hands-on)

- **界面与文件创建**: (源: `008.md`)
- **基础工具**: 
    - 形状 (源: `010.md`)
    - 文本 (源: `009.md`)
    - 颜色 (源: `011.md`)
    - 描边 (源: `012.md`)
- **对象编辑与缩放**: (源: `013.md`, `014.md`)

---

## 课堂活动 (Activity)

- **活动**: 学生跟随教程，访问 `randomprojectgenerator.com` 创建自己的项目简介，并导入 `Task Flow.fig` 文件，为自己的项目做好准备。(源: `006.md`)

---

## 核心产出 (Weekly Deliverable)

- **任务**: **Class Project 02 - Wireframe**。学生需要提交一个至少包含4个页面（主页、产品详情、结算、确认）的个人项目线框图 `.fig` 文件。(源: `016.md`)

---

## 常见陷阱/难点 (Common Pitfalls)

- **画框 (Frame) 与组 (Group) 的混淆**：务必向学生强调，Frame是带有尺寸的“画板”，而Group仅仅是对象的集合。这是Figma与传统设计软件的核心区别之一。