# Weekly Unit Template

---

# {{week_title}}

## 本周目标 (Overall Goal)

## 核心概念 (Concepts)

## 核心技能演示与实操 (Demo & Hands-on)

## 课堂活动 (Activity)

## 本周核心产出 (Weekly Deliverable)