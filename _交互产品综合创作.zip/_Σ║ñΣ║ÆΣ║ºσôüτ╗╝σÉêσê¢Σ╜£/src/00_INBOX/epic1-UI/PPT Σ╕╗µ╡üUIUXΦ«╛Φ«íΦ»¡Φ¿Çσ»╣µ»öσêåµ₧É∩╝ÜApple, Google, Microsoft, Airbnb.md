---
marp: true
theme: uncover
---

# **4个品牌的UI/UX设计语言**

**对比分析: Apple, Google, Microsoft, Airbnb**
主流UI/UX设计语言对比分析：Apple, Google, Microsoft, Airbnb


---

## **什么是设计语言 (Design Language)？**

- **定义**: 一套用于产品设计的共享准则、原则和模式的集合。
- **目的**:
    - **一致性 (Consistency)**: 确保在不同平台和产品中提供统一的用户体验。
    - **品牌识别 (Brand Identity)**: 强化品牌形象和价值观。
    - **效率 (Efficiency)**: 加速设计和开发流程。

---

## **1. Apple - Human Interface Guidelines (HIG)**

- **核心原则**:
    - **清晰 (Clarity)**: 文本清晰易读，图标精确易懂。
    - **遵从 (Deference)**: UI 辅助内容，而不是与内容竞争。
    - **深度 (Depth)**: 利用分层和动态效果传达层次结构。
- **特点**: 简洁、直观、注重内容、大量使用模糊和半透明效果。
- **平台**: iOS, macOS, watchOS, tvOS

---

## **2. Google - Material Design**

- **核心隐喻**: **材质隐喻 (Material as a Metaphor)**。将物理世界的质感（如纸张和墨水）引入数字界面。
- **核心原则**:
    - **大胆、图形化、有意义 (Bold, graphic, intentional)**: 设计决策应清晰且有目的。
    - **动效赋予意义 (Motion provides meaning)**: 动画和过渡效果能有效引导用户注意力。
- **特点**: Z轴概念、阴影、图层、鲜艳的色彩、响应式动画。

---

## **3. Microsoft - Fluent Design System**

- **五大核心元素**:
    - **光线 (Light)**: 吸引注意力。
    - **深度 (Depth)**: 创造层次感。
    - **动效 (Motion)**: 连接情境。
    - **材质 (Material)**: 模拟真实物理质感（如亚克力效果）。
    - **缩放 (Scale)**: 跨越不同尺寸和形态的设备。
- **目标**: 在从屏幕到混合现实的各种设备上创造和谐、直观的体验。

---

## **4. Airbnb - Design Language System (DLS)**

- **核心理念**: **统一、高效、美观 (Unified, Efficient, Beautiful)**。
- **方法**: 通过系统化的组件库来构建产品，确保任何设计师都能快速创建符合规范的界面。
- **特点**:
    - **组件驱动 (Component-driven)**: 设计和代码组件一一对应。
    - **内容为中心 (Content-centric)**: 特别是高质量的摄影图片。
    - **清晰、简洁、通用**。

---

## **总结与对比**

| 品牌 | 核心理念 | 关键词 |
| :--- | :--- | :--- |
| **Apple** | 内容优先，UI退后 | 清晰, 遵从, 深度, 直观 |
| **Google** | 物理世界的数字隐喻 | 材质, 纸张, 阴影, 动效 |
| **Microsoft** | 跨设备的多维感官体验 | 光线, 深度, 材质, 缩放 |
| **Airbnb** | 系统化、可扩展的设计 | 统一, 高效, 组件化, 系统 |

---

## **Q&A**

**感谢观看！**
