### 免费版 vs 专业版  

付费用户：每月18美元订阅  

![bg fit left:50% vertical](https://i.imgur.com/pY96FeX.webp)


---


### 教育认证获取 Figma专业版==部分==权益  

- 无限文件 & 无限项目  
- 无限版本历史记录  
- 团队库功能 , 无限编辑者 & 团队成员  
- 私有项目权限  
- Dev Mode（开发者模式） , MCP功能
- 视频插入功能  

==不含Figma sites及AI功能  ==

(_闲鱼 1 元有 Figma 教育认证 “一键” 服务._)








 





