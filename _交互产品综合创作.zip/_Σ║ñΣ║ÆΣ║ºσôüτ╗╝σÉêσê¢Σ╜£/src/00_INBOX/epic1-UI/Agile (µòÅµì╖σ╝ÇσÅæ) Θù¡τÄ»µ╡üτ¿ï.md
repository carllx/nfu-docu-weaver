	[[vid - BMAD Vibe Coding Workflow Is a Massive Level Up]]

- **Agile** (敏捷开发)：一套软件开发实践的统称，强调通过短周期的迭代、增量交付、团队协作和快速响应变化来构建软件。
![bg fit left:50% vertical](https://i.imgur.com/5Dt7EQk.webp)
