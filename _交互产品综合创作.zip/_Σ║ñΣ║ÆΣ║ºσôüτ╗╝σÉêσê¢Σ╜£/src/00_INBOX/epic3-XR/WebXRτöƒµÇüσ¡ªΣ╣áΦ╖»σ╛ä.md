[ 🔍 google Google Gemini](@https://gemini.google.com/u/1/app/ab27f4984ee8d498)
[ 🔍 google WebXR框架学习路径研究 Docs](@https://docs.google.com/document/d/1CcnDfHl-ObZdPre6f0RYmsPJuKUyIZ3Mj1ln79KcK6w/edit?tab=t.0)


# WebXR生态系统开发者指南

# WebXR生态系统开发者指南：框架、资源与战略学习路径

  

## 第一部分：沉浸式网络的基础

  

为了构建引人入胜的WebXR体验，开发者必须首先掌握其技术基石。本部分旨在深入剖析构成沉浸式网络核心的技术与概念，确保读者在探索“如何做”之前，能深刻理解“为什么”。

  

### 1.1 解构WebXR设备API

  

WebXR设备API（WebXR Device API）是由万维网联盟（W3C）制定的 foundational 标准，它构成了网页内容与XR（扩展现实）硬件之间通信的桥梁，这些硬件包括虚拟现实（VR）头戴显示器、增强现实（AR）眼镜等 1。作为已废弃的WebVR API的继任者，WebXR极大地扩展了其范畴，将增强现实也纳入了支持范围，从而统一了整个沉浸式网络的技术栈 3。

一个至关重要的概念是，WebXR本身并不是一个渲染引擎。它的核心职责在于管理与XR设备相关的特定任务：

- 会话管理 (Session Management): 启动、管理和终止沉浸式会话。
    
- 设备追踪 (Device Tracking): 获取头戴显示器和控制器的实时位置与姿态（pose）信息。
    
- 输入处理 (Input Processing): 接收来自手持控制器等输入设备的信号，如扳机键（select）和握持键（squeeze）的按下事件 1。
    
- 渲染循环管理 (Render Loop Management): 协调渲染过程，确保每一帧画面都能在正确的时间点、以正确的视角呈现给用户 1。
    

该API通过一系列接口（如XRSession、XRView、XRPose）来暴露这些功能 3。它支持的设备范围极广，从需要连接电脑的高端头显（如HTC Vive、Oculus Rift），到独立的VR设备（如Meta Quest），再到能够实现“魔法窗口”式AR体验的智能手机，几乎涵盖了所有主流的XR硬件形态 2。

这种设计哲学背后，是对硬件市场现状的深刻洞察。当前的XR硬件市场呈现出高度多样化和快速迭代的特点，不同厂商的设备（如Oculus、Vive、HoloLens、Apple Vision Pro）拥有各自独特的硬件能力和SDK 3。如果开发者需要为每一种设备编写定制化的代码，将不可避免地陷入平台碎片化的困境，这极大地阻碍了内容的普及和生态的发展。WebXR设备API正是为了解决这一核心痛点而生。它扮演着一个通用翻译层的角色：开发者面向统一的WebXR标准进行编程，而浏览器（如Chrome、Oculus Browser、Safari for visionOS）则负责将这些标准化的API调用转换为特定设备的指令 3。这一机制赋予了WebXR“一次编写，处处运行”的强大能力，不仅简化了跨平台开发，更使得开发者创作的内容能够面向未来，兼容未来不断涌现的新硬件，这相对于需要为每个平台单独打包发布的原生开发模式，是一个根本性的优势 5。

  

### 1.2 渲染引擎：WebGL不可或缺的角色

  

既然WebXR本身不负责图形渲染，那么它必须与一个图形API协同工作。在当前的Web技术栈中，这个角色几乎无一例外地由WebGL（及其后续版本WebGL2）扮演 1。

WebGL是一个基于OpenGL ES（嵌入式系统开放图形库）标准的JavaScript API，它允许在浏览器中直接利用GPU进行硬件加速的2D和3D图形渲染，无需任何插件 6。

在一个典型的WebXR应用中，开发者首先使用WebGL来构建3D场景——创建模型、设置光源、应用纹理等。随后，WebXR API介入，为每一帧画面提供渲染所需的关键信息，包括针对左眼和右眼的虚拟摄像机投影矩阵和视点数据。WebXR API会精确地告诉WebGL渲染器何时以及如何将场景绘制到头戴显示器的屏幕上，从而生成具有深度感的立体3D影像 1。

WebXR（负责会话与设备管理）与WebGL（负责图形渲染）之间的这种“关注点分离”是一种强大但复杂的架构。这种分离正是高级框架不仅是便利工具，更是大多数开发者必需品的核心原因。直接使用WebGL编程是出了名的冗长和复杂，开发者需要手动管理着色器（shader）、缓冲区（buffer）、矩阵变换等大量底层细节 1。同时，直接操作WebXR API也需要处理复杂的会话状态、引用空间（reference space）和渲染循环逻辑 2。如果一个开发者试图从零开始整合这两套独立的、复杂的底层API，他必须同时成为两个领域的专家。如此之高的入门门槛无疑会扼杀技术的普及。因此，WebXR生态系统自然而然地催生了A-Frame、Babylon.js、Three.js等一系列上层框架。这些框架将底层的复杂性封装起来，让开发者能够将精力集中在应用逻辑和创意实现上，而不是耗费在繁琐的底层管道搭建工作上。这一演进逻辑，为我们接下来深入探讨框架选择奠定了基础。

  

### 1.3 WebXR应用生命周期

  

出于安全和用户体验的考量，WebXR API规定了一套严格的、以用户为中心的应用流程 2。任何WebXR应用都必须遵循以下生命周期：

1. 检查支持 (Check for Support): 应用首先必须在一个安全的上下文（即通过HTTPS协议加载的页面，或本地localhost）中运行 8。在此前提下，应用通过调用  
    navigator.xr.isSessionSupported()来查询用户的设备和浏览器是否支持所需的目标模式，例如'immersive-vr'（沉浸式VR）或'immersive-ar'（沉浸式AR） 2。如果上下文不安全或设备不支持，  
    navigator.xr属性甚至可能不存在，应用需要优雅地处理这种情况。
    
2. 用户激活 (User Activation): 这是WebXR一项至关重要的安全机制。沉浸式会话只能在响应一个明确的用户操作（如点击按钮）时才能启动 2。此举旨在防止恶意网站在用户不知情的情况下擅自启动XR会话，劫持用户的视觉和听觉。
    
3. 请求会话 (Request Session): 在获得用户激活后，应用调用navigator.xr.requestSession()来正式请求进入沉浸式体验 2。
    
4. 运行渲染循环 (Run Render Loop): 一旦用户的请求被批准，会话便成功创建。应用随即进入一个渲染循环，该循环通常由XRSession.requestAnimationFrame()方法来驱动。在这个循环的每一帧中，应用都需要执行一系列任务：更新场景逻辑（如物体动画、物理模拟）、获取最新的设备姿态信息、然后为左眼和右眼分别绘制场景 2。
    
5. 结束会话 (End Session): 渲染循环会持续进行，直到用户主动选择退出，或者应用通过编程方式调用XRSession.end()来终止会话 2。
    

这套生命周期的设计将用户同意和安全置于开发者便利性之上，对应用的设计和用户界面（UI）产生了深远的影响。由于必须存在一个用户手势来启动会-话，这意味着每一个WebXR体验都必须包含一个非沉浸式的“2D网页”作为入口，上面至少要有一个“进入VR/AR”的按钮。这自然地将用户体验分成了两个阶段：初始的2D网页阶段和随后的3D沉浸式阶段。为了更好地连接这两个世界，WebXR API也衍生出了一些特殊的模块，例如dom-overlay（DOM叠加层）功能。该功能允许开发者将一个标准的2D HTML元素叠加显示在AR会话中，从而在沉浸式环境里继续使用用户所熟悉的网页UI模式，如表单、按钮和文本 9。这充分说明，WebXR并非对传统网络的彻底颠覆，而是一种强大的延伸。成功的WebXR应用必须精心设计和管理2D与3D状态之间的转换，为用户提供无缝、直观的体验。

  

## 第二部分：WebXR框架格局的比较分析

  

本部分将对主流的WebXR开发框架进行深入的、多维度的比较分析，旨在帮助开发者根据自身的技术背景、项目目标和期望的抽象层次，做出最明智的技术选型。

  

### 2.1 抽象的必然性：为何框架至关重要

  

正如第一部分所阐述的，直接利用底层的WebXR和WebGL API进行编程是一项极其复杂的任务，充满了繁琐的数学计算、数据管理和样板代码 1。框架的出现，正是为了解决这一难题。它们构建于这些底层API之上，提供了更高级、更易于使用的抽象。其中一个显著的优势是实现了虚拟摄像机功能。WebGL本身并不直接提供摄像机视图的概念，而一个能够模拟摄像机行为的库，能极大地简化场景导航和渲染的编程工作，尤其是在构建允许用户在虚拟世界中自由移动的应用时 1。在WebXR开发领域，使用框架不仅是普遍做法，更是官方推荐的标准路径，适用于除极少数高度定制化场景外的所有情况 1。

我们可以将整个WebXR生态系统理解为一个技术“栈”，每一层都在其下一层的基础上提供更高层次的抽象。开发者的框架选择，本质上是在决定自己希望在哪个抽象层次上进行工作。

- 第0层 (硬件层): 物理设备本身，如Meta Quest头显。
    
- 第1层 (浏览器/API层): 浏览器对WebXR设备API和WebGL的实现。这是Web开发者能够直接接触到的最低层。
    
- 第2层 (渲染库层): 以Three.js为代表。它将WebGL的冗长细节封装成更易于管理的、面向对象的结构。可以将其视为Web 3D领域的“汇编语言”。
    
- 第3层 (引擎/框架层): A-Frame、Babylon.js、React Three Fiber等。它们进一步抽象了Three.js和WebXR生命周期的复杂性，提供了声明式或基于组件的开发范式。这可以被看作是WebXR领域的“高级语言”。
    

这个分层模型清晰地描绘了整个生态系统的结构，为后续的框架比较提供了一张心智地图。开发者的选择总是一种权衡：向技术栈的上层移动，会获得更高的开发效率和更低的入门门槛，但通常会以牺牲部分细粒度的控制权和可能存在的性能开销为代价。

  

### 2.2 A-Frame：通往VR的声明式门户

  

A-Frame是一个旨在通过类似HTML的声明式语法来构建VR体验的Web框架 11。它构建于强大的Three.js库之上，但为开发者提供了一个截然不同的、更为友好的入口 11。

- 核心范式与架构: A-Frame的核心是实体-组件-系统（Entity-Component-System, ECS）架构 11。在这个模型中，场景中的所有对象都是“实体”（Entity），由  
    `<a-entity>`标签表示。实体本身是空的容器，其外观、行为和功能完全由附加于其上的“组件”（Component）来定义 13。例如，一个简单的立方体可以由一个实体附加  
    geometry（定义形状为盒子）和material（定义颜色）两个组件构成。这种架构极具组合性和可复用性。
    
- 对初学者的友好度: A-Frame对初学者，尤其是拥有Web开发背景的人来说，异常友好。开发者无需安装任何工具链或进行复杂的构建配置，只需在HTML文件中引入一个`<script>`标签，然后创建一个`<a-scene>`元素，即可拥有一个功能完备的VR场景 13。A-Frame会自动处理场景、渲染器、摄像机、光照和默认控制的创建。其HTML语法直观易读，使得艺术家、设计师等非程序员也能轻松上手 13。
    
- 生态系统: A-Frame最强大的优势在于其庞大而活跃的社区以及由此产生的繁荣的组件生态系统。社区贡献了成百上千的组件，涵盖了物理引擎、粒子系统、多人网络同步（如Networked-Aframe）、高级控制器交互、环境生成等几乎所有可以想到的功能 13。
    
- WebXR集成: A-Frame无缝地集成了WebXR，开发者无需手动处理会话管理的复杂逻辑。更高级的WebXR配置可以通过webxr系统组件来实现，允许开发者精细地设置referenceSpaceType（引用空间类型），并声明应用所需的或可选的WebXR特性，如hit-test（命中测试）或dom-overlay（DOM叠加层） 9。
    

A-Frame的设计体现了一种战略性的取舍：优先考虑降低入门门槛和促进生态系统增长，而非追求极致的底层性能。它的巨大成功证明了一个开放、活跃的社区所能释放的巨大能量。通过采用HTML作为其核心语法，A-Frame向地球上最庞大的开发者群体——Web开发者——敞开了大门，这是一个旨在最大化开发者基数的明智之举 20。这种易于上手的特性催生了社区的快速成长和分享文化的形成 17。ECS架构完美地契合了这一模式，因为它允许将复杂的新功能（如一个物理引擎）封装成一个独立的组件，作为一个小巧的、可插拔的模块进行分发和共享 18。这形成了一个良性循环：开发者需要某个功能，在社区中找到相应的组件并使用它，然后可能受到启发，自己也去创造和分享新的组件。最终，A-Frame的能力边界是由其庞大的社区组件库（A-Frame Registry）和其核心代码共同定义的 18。这使得A-Frame成为快速原型开发、教育以及任何可以利用现有社区解决方案的项目的无与伦比的工具。

  

### 2.3 Babylon.js：一体化的Web渲染引擎

  

Babylon.js是一个功能强大且全面的3D游戏和渲染引擎，以JavaScript框架的形式提供 16。它将自己定位为一个完整的解决方案，常被誉为“Web版的Unity或Unreal引擎”。

- 核心范式与架构: Babylon.js采用的是更为传统的、面向对象的游戏引擎架构。它提供了一套丰富而强大的API，允许开发者通过编写JavaScript或TypeScript代码来创建场景、网格、材质、光照，并实现复杂的交互逻辑和行为 10。
    
- WebXR集成: Babylon.js提供了高度简化且功能强大的WebXR集成方案。其核心是WebXRDefaultExperience辅助类，开发者只需一行代码（scene.createDefaultXRExperienceAsync()），即可为场景添加一整套开箱即用的VR功能，包括一个“进入XR”的UI按钮、控制器输入处理、激光指针选择以及传送移动功能 21。
    
- 高级特性: Babylon.js的真正实力体现在其WebXRFeaturesManager（WebXR特性管理器）上。这个管理器允许开发者以模块化的方式，精细地启用、禁用和配置各种高级WebXR模块，例如手部追踪、图层（可用于实现多视图渲染等性能优化）、命中测试、平面检测和锚点（用于构建复杂的AR体验） 10。
    
- 工具链: Babylon.js拥有一个成熟的工具生态系统，包括功能强大的可视化场景检查器（Inspector）和用于实时编码、分享实验的“Playground”在线编辑器，这些都极大地提升了开发体验 16。
    

Babylon.js的架构设计明确地指向了那些希望在Web平台上构建复杂、高保真、类似游戏的应用的开发者。它提供的能力更接近于原生游戏引擎，而非其他轻量级的WebXR库。诸如WebXRDefaultExperience这样的辅助类，展示了其致力于将常见的VR交互模式（如传送、抓取）抽象化的设计理念，这些功能如果从零开始实现将非常耗时 23。这正是一个成熟游戏引擎的标志——它不仅提供渲染能力，还提供解决常见游戏设计问题的方案。

WebXRFeaturesManager 25 更是其目标用户的明证。它提供了一种结构化、健壮的方式来访问WebXR规范中那些前沿的、可选的特性。这专为那些需要突破AR/VR技术边界、并要求对应用所使用的设备能力有精细控制的专业开发者而设计。Babylon.js为每一个高级特性都提供了详尽的官方文档和支持 10，这与A-Frame在很大程度上依赖社区组件的做法形成了鲜明对比。Babylon.js的目标是将这些高级功能作为核心引擎的一部分，提供稳定、官方的保障。因此，对于拥有强大编程能力、致力于构建商业级、功能丰富的XR应用，并且偏爱一个“开箱即用”、官方支持完备的引擎而非模块化、社区驱动方案的团队来说，Babylon.js是最佳选择。

  

### 2.4 Three.js：追求极致控制的基础库

  

Three.js是一个底层的3D图形库，其核心目标是简化WebGL的编程 16。它既不是游戏引擎，也不是声明式框架，而是一个抽象层，提供了用于构建场景、摄像机、网格、材质等3D世界基本元素的JavaScript对象。

- 在生态系统中的角色: Three.js是整个WebXR生态的基石，A-Frame和React Three Fiber都构建于其上 11。因此，熟练掌握Three.js具有极高的价值，它能让开发者在需要时“揭开”上层框架的“引擎盖”，理解其内部工作原理。
    
- WebXR集成: 在Three.js中，WebXR的支持是通过WebGLRenderer内部的WebXRManager类来管理的 32。与A-Frame或Babylon.js相比，这需要更多的手动设置。开发者需要自己创建“进入VR”的按钮，在用户点击后请求XR会话，并显式地在渲染器上启用XR模式 30。
    
- 控制器管理: Three.js提供了对控制器的高度精细化控制。通过getController()（用于获取代表指向射线的组）、getControllerGrip()（用于获取代表抓握位置的组，适合放置手持物体）和getHand()（用于手部追踪可视化）等方法，开发者可以精确地构建自己想要的交互模型 32。
    
- 灵活性与复杂度的权衡: Three.js提供了最大程度的灵活性和最高的性能潜力，因为它最接近底层的WebGL和WebXR API。然而，这种自由度的代价是显著增加的样板代码和更陡峭的学习曲线 30。诸如传送、抓取等高级交互功能，都需要开发者自行实现。
    

Three.js在WebXR生态系统中占据了一个至关重要的中间位置，它是Web 3D领域的“通用语”。选择直接使用Three.js进行开发，意味着开发者决定用开发速度来换取极致的控制权和性能优化能力。当一个新的WebXR特性被标准化时，它很可能会首先在Three.js的WebXRManager中得到实现，然后才会被上层的A-Frame或Babylon.js封装成更易用的辅助功能。直接使用Three.js能让开发者在第一时间接触到最新的技术能力。此外，高级框架通常会对交互模式做出一些预设（例如Babylon.js的默认传送机制），如果项目需要一种全新的、独特的交互范式，这些预设反而可能成为障碍。Three.js则不作任何假设，为开发者提供了一张完全空白的画布 32。对于性能要求极为苛刻的应用，可能需要绕过框架层带来的额外开销。由于Three.js是直接位于WebGL之上的抽象层，它为性能优化（如手动管理绘制调用、实现自定义的剔除算法）提供了最直接的路径 30。因此，对于那些致力于构建高度定制化、高性能体验的开发者，或是希望创建可复用交互库的工程师，以及那些渴望从根本上深入理解WebXR工作原理的学习者来说，Three.js是理想的选择。

  

### 2.5 React Three Fiber (R3F)：React生态的强大赋能

  

React Three Fiber（简称R3F）并非一个传统的3D框架，而是一个针对Three.js的React渲染器。它允许开发者使用React组件、状态（state）和钩子（hooks）来声明式地构建Three.js场景 31。需要强调的是，R3F不是一个简单的封装库，而是一个完整的协调（reconciliation）渲染器，其工作方式类似于React-DOM将React组件树渲染为浏览器DOM 35。

- WebXR集成: @react-three/xr库为R3F带来了强大的WebXR能力。开发者只需将场景包裹在<XR>组件（在旧版本中为<VRCanvas>）中，即可自动获得会话管理、默认控制器设置和一个“进入VR”按钮 31。
    
- 开发者体验: 对于React开发者而言，R3F是革命性的。它使得开发者能够将在2D Web开发中积累的React技能和整个生态系统（如使用Zustand或Redux进行状态管理、路由库等）无缝迁移到3D应用开发中 34。它提供了一套优秀的事件系统和合理的交互默认设置，开发者可以用几行代码就构建出可交互的体验 36。
    
- 生态系统: R3F生态中一个极其重要的部分是drei库，它为R3F提供了一个庞大的、可复用的辅助组件和钩子集合，其地位类似于A-Frame的组件库，极大地简化了常见3D任务的实现 31。
    

R3F的出现和流行，是React在整个Web开发领域占据主导地位的直接结果 37。它代表了3D开发的“React化”趋势，成功地在声明式的UI世界和命令式的3D图形世界之间架起了一座桥梁。传统的Three.js开发是命令式的（例如

scene.add(mesh); mesh.position.x = 5;），这与React“描述状态，由渲染器负责更新”的范式存在冲突。R3F通过创建一个能将React组件树（例如 <mesh position={} />）翻译成命令式Three.js调用的渲染器，解决了这个根本性的矛盾。这意味着一个拥有React技术栈的团队，无需重新招聘或培训一套完全不同的技能，就能立即投入WebXR应用的开发，他们可以复用已有的专业知识、工具和工作流程 34。因此，R3F不仅仅是又一个框架，它是一个战略性的赋能工具，为庞大的React开发者社区打开了通往3D和XR世界的大门。对于任何已经投入React生态的个人或组织来说，R3F是进入WebXR领域的最佳路径。

  

### 2.6 框架综述与决策矩阵

  

为了帮助开发者快速做出判断，下表将前述的详细分析综合成一个直观的比较矩阵。

表1：WebXR框架概览

|   |   |   |   |   |
|---|---|---|---|---|
|特性|A-Frame|Babylon.js|Three.js|React Three Fiber (@react-three/xr)|
|核心范式|声明式HTML (ECS架构)|全功能游戏引擎 (面向对象)|底层3D库 (命令式)|React渲染器 (声明式组件)|
|目标开发者|Web开发者、艺术家、设计师、教育者|游戏开发者、企业级应用开发者|图形程序员、库/工具开发者|React开发者|
|学习曲线|最低|较陡|最陡|中等 (若熟悉React则较低)|
|核心优势|快速原型、庞大的组件生态、极易上手|"开箱即用"、功能强大、工具链完善|极致的控制权、灵活性、性能潜力|无缝的React集成、卓越的开发体验|
|主要权衡|性能开销、控制力相对较弱|代码较冗长、对简单项目可能过重|复杂度高、需自行实现大量功能|引入React依赖、存在抽象层开销|

  

## 第三部分：WebXR精通之路的最佳学习路径

  

本部分将提供一个结构化的、分阶段的课程体系，旨在引导学习者从零基础开始，逐步成长为WebXR领域的专家，并在每个阶段提供可行的建议和项目实践。

  

### 3.1 第一阶段：掌握基础 (第1个月)

  

这一阶段的核心目标是为学习者构建一个坚实的、可迁移的3D计算机图形学理论和基础WebGL概念的知识体系。这些知识是框架无关的，对于长期的职业发展至关重要。

- 学习内容:
    

- 3D图形学理论: 深入学习核心概念，包括笛卡尔坐标系（X, Y, Z轴）、变换（平移、旋转、缩放）、向量和矩阵数学的基础。
    
- 图形渲染管线: 理解图形从数据到像素的基本流程：顶点数据、着色器（顶点着色器与片元着色器）、光栅化和最终的像素输出。
    
- 光照与材质: 学习不同类型的光源（环境光、平行光、点光源）及其效果，以及基础的材质属性（颜色、高光、纹理贴图）。
    

- 推荐资源:
    

- 学习的起点应该是基础的WebGL书籍，如**《WebGL编程指南》或《WebGL: Up and Running》** 39。这些书籍对于建立核心理解非常有价值。对于希望获得更深入、更学术性知识的学习者，**《交互式计算机图形学》**是一个更佳的选择 39。
    

一个常见的错误是，初学者直接从A-Frame这样的高级框架入手，而跳过了对底层原理的学习，这很容易导致他们迅速达到一个“能力天花板”。例如，一个开发者可能通过一行<a-box color="red">快速看到了成果，但当他们需要实现一个自定义的视觉效果或调试一个奇怪的渲染问题时，就会因为不理解“材质”或“着色器”在底层是如何工作的而束手无策。此时，高级框架的抽象就变成了一个无法修改或调试的“黑箱”。反之，如果开发者愿意投入一个月的时间来学习3D图形学的基础，他们就获得了从第一性原理出发思考和解决问题的能力。这种能力可以迁移到任何框架或引擎（无论是A-Frame、Babylon.js，还是Unity、Unreal）。这笔初期的学习投资，将在未来的职业生涯中带来巨大的回报。

  

### 3.2 第二阶段：初识框架与首批项目 (第2-4个月)

  

在掌握了基础理论后，第二阶段的重点是将这些知识付诸实践，通过学习一个高级框架来完成一些简单的、非交互式的项目。

- 框架选择决策树:
    

- 如果你是React开发者，或团队技术栈以React为主: 毫无疑问，应该从React Three Fiber开始。由于可以利用已有的React知识，学习曲线将最为平缓 31。
    
- 如果你是刚接触3D的Web开发者、艺术家，或者你的主要目标是快速实现原型: 应该选择A-Frame。其基于HTML的开发方式是让场景快速运行起来的最便捷途径 13。
    
- 如果你有游戏开发背景，或者计划构建一个复杂、功能丰富的应用: 那么Babylon.js是你的不二之选。它类似游戏引擎的结构会让你倍感亲切，其内置的强大功能将极大地加速开发进程 16。
    

- 建议项目:
    

- 项目1：360°全景图片浏览器: 创建一个简单的场景，用户可以在其中环顾一张360°全景图。这个项目将教会你如何设置场景、使用天空盒（skybox）以及控制基础相机。（A-Frame官方文档中有此项目的教程 13）。
    
- 项目2：太阳系模型: 在场景中放置多个球体代表行星，并让它们围绕中心点进行自转和公转。这个项目将帮助你掌握对象层级（父子关系）、变换以及基础的动画循环。（Codecademy为A-Frame提供了此项目的课程 12）。
    
- 项目3：简单模型查看器: 加载一个外部的3D模型文件（例如.gltf格式），并在场景中展示出来。这是任何实际应用都必须掌握的关键技能——资源加载 33。
    

  

### 3.3 第三阶段：中级技术与交互性 (第5-9个月)

  

这一阶段的目标是从静态场景迈向可交互的体验，核心是处理用户输入并开始关注性能问题。

- 学习内容:
    

- 控制器输入: 学习如何检测控制器的存在，并处理核心输入事件，如select（扳机键按下）和squeeze（握持键按下）。在A-Frame中，这通常通过laser-controls等组件实现 13；在Babylon.js中，由  
    WebXRInput系统处理 23；而在Three.js中，则需要使用  
    getController()系列方法 32。
    
- 交互实现: 实现基础的交互逻辑，如基于视线或控制器射线的悬停高亮（光线投射/Raycasting），以及抓取和移动物体。R3F的@react-three/xr库提供了一个<Hover>组件来简化这一过程 31。
    
- 性能分析入门: 这是成为专业开发者的关键一步。学习使用浏览器开发者工具和框架自带的检查器（Inspector）来分析应用的性能瓶颈，判断应用是CPU密集型（逻辑计算过多或绘制调用次数过多）还是GPU密集型（几何体过于复杂或着色器计算量过大）。Meta的官方性能文档对此有详细的指导 41。
    
- 基础优化: 学习初步的优化技巧，例如减少模型的面数、使用压缩纹理、以及通过实例化（instancing）来批量处理绘制调用 30。
    

- 建议项目:
    

- 项目4：VR迷你高尔夫游戏: 一个简单的游戏，用户可以用控制器瞄准并击打高尔夫球。这个项目将综合运用光线投射、物理引擎（可借助Cannon.js或PhysX等库）以及基础的游戏状态管理 5。
    
- 项目5：交互式产品配置器: 加载一个产品模型（如汽车或家具），允许用户通过点击模型的不同部分来改变其颜色或材质。这个项目将锻炼你在3D对象上的事件处理和动态材质更新能力。
    

  

### 3.4 第四阶段：高级开发与专业化 (第10个月及以后)

  

进入这一阶段，学习者将开始攻克专家级的主题，并根据兴趣和职业方向进行专业化深造。

- 学习内容:
    

- 高级AR技术: 深入研究AR特有的功能，包括命中测试（Hit-Testing，从设备投射一条虚拟射线以检测与真实世界表面的交点）、平面检测（Plane Detection，识别真实环境中的地板、墙壁、桌面等平面）和锚点（Anchors，创建能够锁定在真实世界某个位置的虚拟对象）。Babylon.js为这些高级AR功能提供了全面且稳定的官方支持 10。
    
- 自定义着色器 (GLSL): 为了实现独特的视觉效果或进行极致的性能优化，学习使用GLSL（OpenGL着色语言）编写自己的顶点和片元着色器是必经之路。这将赋予你对渲染管线的终极控制权 39。
    
- 多人在线体验: 学习如何通过WebSocket和后端服务在多个客户端之间同步状态，以创建共享的虚拟体验。像networked-aframe这样的库为此提供了一个很好的起点 15。
    
- 性能深度优化: 探索更高级的优化技术，例如使用**WebAssembly (Wasm)来运行计算密集型任务（如物理模拟）以达到接近原生的性能 42，以及利用WebXR的  
    图层（Layers）和注视点渲染（Foveated Rendering）**等高级特性来降低GPU负载 26。
    

- 建议项目:
    

- 项目6：AR家具摆放应用: 使用手机摄像头扫描并识别房间地面，然后将虚拟家具模型放置在真实空间中。这需要熟练运用命中测试和平面检测技术。
    
- 项目7：共享虚拟白板: 一个多人在线应用，允许多个用户进入同一个VR房间，并一起在三维空间中进行绘画和协作。这需要掌握网络同步和状态管理技术。
    

  

## 第四部分：WebXR必备资源汇编

  

本部分旨在提供一个经过精心筛选和分类的高质量学习资源列表，以在开发者的整个学习旅程中提供支持。

  

### 4.1 基础理论：经典书籍与数字宝典

  

研究表明，目前市面上缺乏专门以“WebXR”为标题的权威书籍。然而，关于其基础技术——WebGL和Three.js——的优秀教材却非常丰富。这是一个重要的启示：精通始于基础，而最优秀的学习资源也往往聚焦于此。

- WebGL基础:
    

- 《WebGL编程指南》: 专注于3D图形学，内容系统深入，是理解底层渲染原理的首选 39。
    
- 《WebGL: Up and Running》: 一个更温和的入门选择，同时涵盖2D和3D，适合初学者快速上手 39。
    

- Three.js学习:
    

- 《Learning Three.js》: 将WebGL抽象为最流行的3D库，是学习Three.js的经典之作 39。
    

- 高级图形学:
    

- 《WebGL Insights》: 专为有经验的开发者设计，聚焦于性能调优和高级技巧，适合第四阶段的学习者 39。
    
- 《OpenGL 4 Shading Language Cookbook》: 学习自定义着色器（GLSL）的绝佳资源，提供了大量实用的“配方” 39。
    

  

### 4.2 互动学习：课程、教程与官方文档

  

对于快速发展的WebXR技术而言，官方文档和在线教程往往是最权威、最新的信息来源。

- A-Frame:
    

- 官方文档、A-Frame School以及Stemkoski的示例集是极好的入门资源 13。Codecademy也提供了一个不错的入门课程 12。
    

- Babylon.js:
    

- 官方文档极其详尽，包含了从入门到深入研究各项特性（如WebXR）的完整路径，其在线Playground为学习和实验提供了无与伦比的便利 10。
    

- Three.js:
    

- 官方文档、海量的官方示例以及“Three.js Fundamentals”（原threejs.org/manual）系列文章是不可或缺的学习材料 32。来自Google 40 和Meta 45 的官方教程则提供了非常实用的分步指南。
    

- React Three Fiber:
    

- pmnd.rs网站上的官方文档，以及drei和@react-three/xr代码库中的示例是学习R3F的关键 35。
    

  

### 4.3 开发者工具箱：模拟器与检查器

  

鉴于并非每个开发者都拥有XR头显，且在设备上反复测试效率低下，模拟器成为了开发流程中不可或缺的一环。同样，用于调试3D场景的浏览器内检查器也至关重要。

- WebXR API Emulator: 一款适用于Chrome和Firefox的浏览器扩展，能够模拟头显和控制器，是桌面端开发和初步测试的必备工具 8。Meta也提供了功能强大的Immersive WebXR Emulator 21。
    
- A-Frame Inspector: A-Frame内置的3D可视化检查器，通过快捷键<ctrl> + <alt> + i激活，可实时修改场景图中的对象属性 13。
    
- Babylon.js Inspector: 一个功能极其强大的内置调试工具，可以检查场景的方方面面，从网格属性到材质细节，无所不包 46。
    

  

### 4.4 社区的力量：论坛与交流频道

  

对于WebXR这样一个日新月异的领域，社区频道的价值往往超过静态的书籍，它们是解决疑难杂症和保持技术更新的最佳场所。

- A-Frame: 官方渠道包括用于提问的Stack Overflow、用于实时聊天的Supermedium Discord服务器以及一个Subreddit 17。
    
- Babylon.js: 官方且高度活跃的Babylon.js论坛是获取支持和展示作品的主要平台 47。此外，还有一个由社区维护的、非常活跃的非官方Discord服务器 49。
    
- Three.js: 官方的three.js论坛和官方Discord服务器是主要的社区中心 52。StackOverflow上也积累了大量历史问题和答案 52。
    

表2：推荐学习资源精选

  

|   |   |   |   |   |
|---|---|---|---|---|
|资源类型|资源名称|目标主题/框架|推荐技能水平|核心价值/链接|
|书籍|WebGL Programming Guide|WebGL|初级-中级|系统学习底层渲染原理的最佳选择。|
|书籍|Learning Three.js|Three.js|初级-中级|掌握最核心的Web 3D库的经典教材。|
|书籍|WebGL Insights|WebGL, 性能|高级|深入了解性能优化和高级图形技巧。|
|官方文档|A-Frame Docs|A-Frame|所有水平|最权威、最全面的A-Frame学习资料。|
|官方文档|Babylon.js Docs|Babylon.js|所有水平|极其详尽，包含大量教程和Playground示例。|
|官方文档|Three.js Docs|Three.js|所有水平|学习Three.js API和查看海量示例的首选。|
|在线教程|Three.js Fundamentals|Three.js, WebGL|初级-中级|深入浅出地讲解3D图形学和Three.js原理。|
|在线教程|Meta WebXR First Steps|Three.js, WebXR|初级|官方出品，引导完成一个完整的WebXR项目 45。|
|社区论坛|Babylon.js Forum|Babylon.js|所有水平|官方支持，最活跃的Babylon.js问题求助和作品分享社区 47。|
|社区论坛|three.js Forum|Three.js|所有水平|官方支持，Three.js开发者交流的主要平台 53。|
|Discord|Supermedium (A-Frame)|A-Frame|所有水平|A-Frame核心团队和社区成员的实时交流频道 17。|
|Discord|three.js Official|Three.js|所有水平|官方Discord服务器，氛围活跃 54。|
|工具|WebXR API Emulator|WebXR|所有水平|桌面端开发和调试WebXR应用的必备浏览器扩展 8。|

  

## 第五部分：结论 - 沉浸式网络的演进边界

  

本部分将对WebXR的现状进行前瞻性的总结，在正视当前挑战的同时，展望未来的发展趋势及其蕴含的巨大潜力。

  

### 5.1 正视障碍：性能与碎片化

  

尽管WebXR描绘了宏伟的蓝图，但它在当前阶段仍面临着不容忽视的挑战。首先是性能差距。与原生应用相比，WebXR应用在执行计算密集型任务时存在明显的性能鸿沟 42。这限制了其在需要复杂物理模拟或大规模场景渲染的应用中的表现。其次是

平台碎片化问题。虽然WebXR API旨在消除硬件差异，但其在不同浏览器和设备上的支持程度仍不一致。尤其是在iOS生态中，用户需要通过一个专门的浏览器应用（WebXR Viewer）才能体验WebXR，这在一定程度上违背了WebXR“即时访问、无需安装”的核心理念 8。此外，行业内对于WebXR技术难度较高或性能不足的固有印象，也构成了其被更广泛采纳的心理障碍 56。

  

### 5.2 前进之路：标准化、Wasm与AI

  

尽管挑战存在，WebXR的未来依然光明，其发展由几个关键趋势驱动。

- 追求性能对等: **WebAssembly (Wasm)**的日益普及被视为弥合WebXR与原生应用性能差距的关键技术。Wasm允许开发者将C++或Rust等高性能语言编译成可在浏览器中以接近原生速度运行的二进制格式。这为在WebXR中实现复杂的CPU密集型计算（如物理引擎、AI算法）开辟了道路 42。
    
- 工具链的成熟: 整个WebXR的开发生态系统，包括上文分析的各大框架和相关工具，正在迅速成熟。这使得开发过程变得更快、更简单。与原生开发漫长的编译-部署周期相比，WebXR的快速迭代能力（在浏览器中保存代码即可看到效果）被开发者誉为一种“超能力”，极大地提升了开发效率和创意的实现速度 56。
    
- 功能集的扩展: WebXR标准本身也在不断演进。新的功能模块，如交互SDK（Interaction SDK）和语音SDK（Voice SDK），正在被逐步标准化，未来将进一步缩小WebXR与原生平台在功能上的差距 56。
    
- 人工智能的融合: 一个新兴但潜力巨大的趋势是将AI技术集成到WebXR体验中。应用场景从利用生成式AI动态生成游戏旁白和内容，到构建更智能、更能响应用户行为的虚拟角色，不一而足 56。AI的加入有望将WebXR的交互性和沉浸感提升到一个全新的高度。
    

  

### 5.3 最终战略建议

  

投身WebXR开发，是对互联网未来的战略性投资。通往成功的最佳路径，并非是简单地选择一个所谓的“最好”的框架，而是要理解整个技术栈的层次结构。一个明智的开发者应当从3D图形学和WebGL的基础原理出发，为自己的知识体系打下坚实的地基；然后，根据自身的背景和项目目标，选择一个合适的高级框架来加速初期的开发；但同时，永远不要忽视那些决定着应用性能和最终体验的底层原则。

通过遵循本报告所规划的结构化学习路径，开发者可以有效地驾驭这个复杂而充满活力的生态系统，从容应对技术选型的挑战，并最终将自己定位在下一代沉浸式网络体验浪潮的最前沿。

#### Works cited

1. Fundamentals of WebXR - Web APIs | MDN - MDN Web Docs - Mozilla, accessed August 7, 2025, [https://developer.mozilla.org/en-US/docs/Web/API/WebXR_Device_API/Fundamentals](https://developer.mozilla.org/en-US/docs/Web/API/WebXR_Device_API/Fundamentals)
    
2. WebXR Device API - W3C, accessed August 7, 2025, [https://www.w3.org/TR/webxr/](https://www.w3.org/TR/webxr/)
    
3. WebXR - Wikipedia, accessed August 7, 2025, [https://en.wikipedia.org/wiki/WebXR](https://en.wikipedia.org/wiki/WebXR)
    
4. immersiveweb.dev, accessed August 7, 2025, [https://immersiveweb.dev/#:~:text=The%20WebXR%20Device%20API%20provides,AR%20experiences%20on%20the%20web.](https://immersiveweb.dev/#:~:text=The%20WebXR%20Device%20API%20provides,AR%20experiences%20on%20the%20web.)
    
5. WebXR, accessed August 7, 2025, [https://immersiveweb.dev/](https://immersiveweb.dev/)
    
6. An Open, Cross-Platform, Web-Based Metaverse Using WebXR and A-Frame - arXiv, accessed August 7, 2025, [https://arxiv.org/html/2408.13520v1](https://arxiv.org/html/2408.13520v1)
    
7. Performance Evaluation of WebGL and WebVR Apps in VR Environments - ResearchGate, accessed August 7, 2025, [https://www.researchgate.net/publication/336821876_Performance_Evaluation_of_WebGL_and_WebVR_Apps_in_VR_Environments](https://www.researchgate.net/publication/336821876_Performance_Evaluation_of_WebGL_and_WebVR_Apps_in_VR_Environments)
    
8. Starting up and shutting down a WebXR session - Web APIs, accessed August 7, 2025, [https://developer.mozilla.org/en-US/docs/Web/API/WebXR_Device_API/Startup_and_shutdown](https://developer.mozilla.org/en-US/docs/Web/API/WebXR_Device_API/Startup_and_shutdown)
    
9. webxr - A-Frame, accessed August 7, 2025, [https://aframe.io/docs/1.7.0/components/webxr.html](https://aframe.io/docs/1.7.0/components/webxr.html)
    
10. WebXR Augmented Reality Features | Babylon.js Documentation, accessed August 7, 2025, [https://doc.babylonjs.com/features/featuresDeepDive/webXR/webXRARFeatures](https://doc.babylonjs.com/features/featuresDeepDive/webXR/webXRARFeatures)
    
11. A-Frame Basics - Educative.io, accessed August 7, 2025, [https://www.educative.io/courses/become-proficient-in-webxr-create-xr-experiences-using-a-frame/a-frame-basics](https://www.educative.io/courses/become-proficient-in-webxr-create-xr-experiences-using-a-frame/a-frame-basics)
    
12. Learn A-Frame (VR) - Codecademy, accessed August 7, 2025, [https://www.codecademy.com/learn/learn-a-frame](https://www.codecademy.com/learn/learn-a-frame)
    
13. Introduction – A-Frame, accessed August 7, 2025, [https://aframe.io/docs/](https://aframe.io/docs/)
    
14. Building up a basic demo with A-Frame - Game development - MDN Web Docs - Mozilla, accessed August 7, 2025, [https://developer.mozilla.org/en-US/docs/Games/Techniques/3D_on_the_web/Building_up_a_basic_demo_with_A-Frame](https://developer.mozilla.org/en-US/docs/Games/Techniques/3D_on_the_web/Building_up_a_basic_demo_with_A-Frame)
    
15. Building an app? These are the best JavaScript frameworks in 2025 - Contentful, accessed August 7, 2025, [https://www.contentful.com/blog/best-javascript-frameworks/](https://www.contentful.com/blog/best-javascript-frameworks/)
    
16. Top JavaScript Libraries for Creating Stunning VR Experiences in 2025 - MoldStud, accessed August 7, 2025, [https://moldstud.com/articles/p-top-javascript-libraries-for-creating-stunning-vr-experiences-in-2025](https://moldstud.com/articles/p-top-javascript-libraries-for-creating-stunning-vr-experiences-in-2025)
    
17. Community - A-Frame, accessed August 7, 2025, [https://aframe.io/community/](https://aframe.io/community/)
    
18. Component Directory - A-Frame Wiki, accessed August 7, 2025, [https://aframe.wiki/en/#!pages/component-directory.md](https://aframe.wiki/en/#!pages/component-directory.md)
    
19. A-Frame Examples - Stemkoski's github page, accessed August 7, 2025, [https://stemkoski.github.io/A-Frame-Examples/](https://stemkoski.github.io/A-Frame-Examples/)
    
20. A-Frame Presentation, accessed August 7, 2025, [https://aframe.io/aframe-presentation-kit/](https://aframe.io/aframe-presentation-kit/)
    
21. WebXR - Babylon.js Documentation, accessed August 7, 2025, [https://doc.babylonjs.com/features/featuresDeepDive/webXR/introToWebXR](https://doc.babylonjs.com/features/featuresDeepDive/webXR/introToWebXR)
    
22. WebXRDefaultExperience - Babylon.js Documentation, accessed August 7, 2025, [https://doc.babylonjs.com/typedoc/classes/BABYLON.WebXRDefaultExperience](https://doc.babylonjs.com/typedoc/classes/BABYLON.WebXRDefaultExperience)
    
23. WebXR Experience Helpers - Babylon.js Documentation, accessed August 7, 2025, [https://doc.babylonjs.com/features/featuresDeepDive/webXR/webXRExperienceHelpers](https://doc.babylonjs.com/features/featuresDeepDive/webXR/webXRExperienceHelpers)
    
24. WebXR - Babylon.js Documentation, accessed August 7, 2025, [https://doc.babylonjs.com/features/featuresDeepDive/webXR](https://doc.babylonjs.com/features/featuresDeepDive/webXR)
    
25. WebXRFeaturesManager - Babylon.js Documentation, accessed August 7, 2025, [https://doc.babylonjs.com/typedoc/classes/BABYLON.WebXRFeaturesManager](https://doc.babylonjs.com/typedoc/classes/BABYLON.WebXRFeaturesManager)
    
26. WebXR Layers - Babylon.js Documentation, accessed August 7, 2025, [https://doc.babylonjs.com/features/featuresDeepDive/webXR/WebXRSelectedFeatures/WebXRLayers/](https://doc.babylonjs.com/features/featuresDeepDive/webXR/WebXRSelectedFeatures/WebXRLayers/)
    
27. WebXRPlaneDetector - Babylon.js Documentation, accessed August 7, 2025, [https://doc.babylonjs.com/typedoc/classes/BABYLON.WebXRPlaneDetector](https://doc.babylonjs.com/typedoc/classes/BABYLON.WebXRPlaneDetector)
    
28. WebXR Babylon.js: Hit Testing by Taikonauten - Medium, accessed August 7, 2025, [https://medium.com/taikonauten-magazine-english/webxr-with-babylon-js-part-4-hit-testing-2994a0866534](https://medium.com/taikonauten-magazine-english/webxr-with-babylon-js-part-4-hit-testing-2994a0866534)
    
29. Babylon.js Tutorial For Absolute Beginners - YouTube, accessed August 7, 2025, [https://www.youtube.com/watch?v=e6EkrLr8g_o](https://www.youtube.com/watch?v=e6EkrLr8g_o)
    
30. How to Develop a WebXR App in Three.js? I Blogs, accessed August 7, 2025, [https://www.threejsdevelopers.com/blogs/how-to-develop-a-webxr-app-in-threejs/](https://www.threejsdevelopers.com/blogs/how-to-develop-a-webxr-app-in-threejs/)
    
31. Write your first VR web application using React and WebXR ..., accessed August 7, 2025, [https://blog.dubenko.dev/react-xr/](https://blog.dubenko.dev/react-xr/)
    
32. WebXRManager – three.js docs, accessed August 7, 2025, [https://threejs.org/docs/api/en/renderers/webxr/WebXRManager.html](https://threejs.org/docs/api/en/renderers/webxr/WebXRManager.html)
    
33. three.js manual, accessed August 7, 2025, [https://threejs.org/manual/](https://threejs.org/manual/)
    
34. WebXR Performance Testing with React: Revolutionizing Mixed Reality Development, accessed August 7, 2025, [https://www.thisdot.co/case-study/rebecker](https://www.thisdot.co/case-study/rebecker)
    
35. Advantages and disadvantages of react-three-fiber - Questions - three.js forum, accessed August 7, 2025, [https://discourse.threejs.org/t/advantages-and-disadvantages-of-react-three-fiber/49160](https://discourse.threejs.org/t/advantages-and-disadvantages-of-react-three-fiber/49160)
    
36. @react-three/xr: Build WebXR experiences with react + three : r/WebXR - Reddit, accessed August 7, 2025, [https://www.reddit.com/r/WebXR/comments/1e4tvnp/reactthreexr_build_webxr_experiences_with_react/](https://www.reddit.com/r/WebXR/comments/1e4tvnp/reactthreexr_build_webxr_experiences_with_react/)
    
37. Top 7 Frontend Frameworks to Use in 2025: Pro Advice - Developer Roadmaps, accessed August 7, 2025, [https://roadmap.sh/frontend/frameworks](https://roadmap.sh/frontend/frameworks)
    
38. Top Frontend Technologies and Development Trends in 2025 - Relia Software, accessed August 7, 2025, [https://reliasoftware.com/blog/front-end-technologies](https://reliasoftware.com/blog/front-end-technologies)
    
39. Best WebGL Books For Web Designers & Developers - WhatPixel, accessed August 7, 2025, [https://whatpixel.com/best-webgl-books/](https://whatpixel.com/best-webgl-books/)
    
40. Create an immersive AR session using WebXR | ARCore - Google for Developers, accessed August 7, 2025, [https://developers.google.com/ar/develop/webxr/hello-webxr](https://developers.google.com/ar/develop/webxr/hello-webxr)
    
41. WebXR Performance Optimization Workflow | Meta Horizon OS Developers, accessed August 7, 2025, [https://developers.meta.com/horizon/documentation/web/webxr-perf-workflow/](https://developers.meta.com/horizon/documentation/web/webxr-perf-workflow/)
    
42. Footnotes - arXiv, accessed August 7, 2025, [https://arxiv.org/html/2110.07128v2](https://arxiv.org/html/2110.07128v2)
    
43. WebXR Performance - PICO Developer, accessed August 7, 2025, [https://developer.picoxr.com/document/web/webxr-performance/](https://developer.picoxr.com/document/web/webxr-performance/)
    
44. Introduction to Babylon.js Features, accessed August 7, 2025, [https://doc.babylonjs.com/features/introductionToFeatures](https://doc.babylonjs.com/features/introductionToFeatures)
    
45. WebXR first steps | Meta Horizon OS Developers, accessed August 7, 2025, [https://developers.meta.com/horizon/documentation/web/webxr-first-steps/](https://developers.meta.com/horizon/documentation/web/webxr-first-steps/)
    
46. Welcome to the Exciting World of WebXR and Babylon.js | Taikonauten Magazine - Medium, accessed August 7, 2025, [https://medium.com/taikonauten-magazine-english/welcome-to-the-exciting-world-of-webxr-and-babylon-js-e2dbd406dbcb](https://medium.com/taikonauten-magazine-english/welcome-to-the-exciting-world-of-webxr-and-babylon-js-e2dbd406dbcb)
    
47. r/babylonjs - Reddit, accessed August 7, 2025, [https://www.reddit.com/r/babylonjs/](https://www.reddit.com/r/babylonjs/)
    
48. Why is editor.babylonjs.com not an official part of babylon? - Questions, accessed August 7, 2025, [https://forum.babylonjs.com/t/why-is-editor-babylonjs-com-not-an-official-part-of-babylon/29901](https://forum.babylonjs.com/t/why-is-editor-babylonjs-com-not-an-official-part-of-babylon/29901)
    
49. Babylon.js Discord - Milestone Thread - Off topic, accessed August 7, 2025, [https://forum.babylonjs.com/t/babylon-js-discord-milestone-thread/33350](https://forum.babylonjs.com/t/babylon-js-discord-milestone-thread/33350)
    
50. Has BJS created a Discord channel? - Off topic - Babylon.js Forum, accessed August 7, 2025, [https://forum.babylonjs.com/t/has-bjs-created-a-discord-channel/42992](https://forum.babylonjs.com/t/has-bjs-created-a-discord-channel/42992)
    
51. A few questions about the Babylon.js brand toolkit, accessed August 7, 2025, [https://forum.babylonjs.com/t/a-few-questions-about-the-babylon-js-brand-toolkit/37813](https://forum.babylonjs.com/t/a-few-questions-about-the-babylon-js-brand-toolkit/37813)
    
52. Welcome to the Community: three.js Around the Web, accessed August 7, 2025, [https://discoverthreejs.com/book/introduction/get-help/](https://discoverthreejs.com/book/introduction/get-help/)
    
53. three.js forum, accessed August 7, 2025, [https://discourse.threejs.org/](https://discourse.threejs.org/)
    
54. Three.js - Discord, accessed August 7, 2025, [https://discord.com/invite/56GBJwAnUS](https://discord.com/invite/56GBJwAnUS)
    
55. Three.js – JavaScript 3D Library, accessed August 7, 2025, [https://threejs.org/](https://threejs.org/)
    
56. Building with WebXR at the Presence Platform Hackathon | Meta ..., accessed August 7, 2025, [https://developers.meta.com/horizon/blog/webxr-presence-platform-hackathon-meta-quest/?locale=ru_RU](https://developers.meta.com/horizon/blog/webxr-presence-platform-hackathon-meta-quest/?locale=ru_RU)
    

**