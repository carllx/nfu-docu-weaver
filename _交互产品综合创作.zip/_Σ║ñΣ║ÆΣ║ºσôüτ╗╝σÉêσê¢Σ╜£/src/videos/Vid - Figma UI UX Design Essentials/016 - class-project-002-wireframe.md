# UI/UX Design Course - Class project 02- Wireframe - 中文逐字稿分析

## 基本信息
- 视频标题：UI/UX Design Course - Class project 02- Wireframe
- 视频时长：03:02
- 分析时间：2023-10-27 11:30:00

## 逐字稿内容

### [00:04] Daniel Walter Scott
Hi everyone, it is class project time. Okay, I want you to create something like this. Okay, you might be following along so far and you might be kind of at a similar sort of stage here. If you're not, I want you to build, get all your frames in, okay, I want you to build this first page plus these other three. They're basically just other kind of versions of this first page. Rectangles, lines, some text.
大家好，现在是课堂项目时间。好的，我希望你们能创建出像这样的东西。你可能已经跟着做到现在，并且可能处于一个类似的阶段。如果你还没有，我希望你开始构建，把所有的画框（frames）都放进去，好的，我希望你构建第一个页面，再加上另外三个。它们基本上只是第一个页面的其他版本。用矩形、线条和一些文本来构成。

### [00:25] Daniel Walter Scott
Okay, I want you to keep it reasonably similar to my layout, even if you're like, even if you disagree and you're like, "No, that shouldn't be there." Keep it kind of similar because I want you to be able to follow along with your example throughout this course, okay, and these kind of units help me show you all the different features in Figma. So keep it close to that.
好的，我希望你们的布局和我的保持合理地相似，即使你不同意，觉得“不，那个不应该在那里”。也请保持相似，因为我希望你能在整个课程中，用你自己的例子来跟上进度。好的，这些单元能帮助我向你展示 Figma 中所有不同的功能。所以请尽量保持一致。

### [00:45] Daniel Walter Scott
And the actual requirements for the different class projects are in your exercise files. You'll see something in there called "Class Projects". Open that up and it will look something like this. Okay, we've done this first one, so ignore that now. If you haven't, this website URL will change, kind of building it at the moment, but remember you're going to go to that website and you're going to create your own brief and persona. So we've done that one already, potentially.
不同课堂项目的具体要求在你们的练习文件中。你会看到一个叫做“Class Projects”的文件。打开它，它看起来会是这样。好的，我们已经做完了第一个，所以现在可以忽略它。如果你还没做，这个网站的 URL 会变，目前还在建设中，但记住你要去那个网站，创建你自己的项目简介（brief）和用户画像（persona）。所以我们可能已经做完了那个部分。

### [01:07] Daniel Walter Scott
Then we're up to here. Okay, so use the skills you've learned so far. It should look something like that. If you're looking for a larger version of it, you should be able to zoom in in this PDF, but if you can't, in your exercise files there is the PNG. Okay, Wireframe Example, just a nice big version of it you can look at. There is a Figma file in there as well. Remember, if you can't remember how to do the Figma file stuff, you go home, go to your drafts and hit that and you can import that Figma file. Up to you.
然后我们进行到这里。好的，所以运用你目前学到的技能。它应该看起来像这样。如果你想看一个更大的版本，你应该可以在这个 PDF 文件里放大，但如果不行，你的练习文件里有一个 PNG 图片。好的，线框图范例（Wireframe Example），是一个你可以看的大尺寸版本。那里也有一个 Figma 文件。记住，如果你不记得怎么处理 Figma 文件，你可以回到主页，进入你的草稿箱，点击那个按钮，就可以导入那个 Figma 文件。由你决定。

### [01:37] Daniel Walter Scott
All right, what else needs to be done? Here are the requirements. So four pages, those are the four pages from our task flow. Okay, pick your own color, okay, it doesn't have to be green, and your own font. You lose points if you use Papyrus, Trajan, Brush Script, or Comic Sans. All terrible fonts. Pick a plain, simple font that I don't hate. It's part of the requirements. I'm looking at you, Papyrus.
好的，还有什么需要做的？这里是要求。总共四个页面，就是我们任务流程（task flow）里的那四个页面。好的，选择你自己的颜色，不一定要是绿色，还有你自己的字体。如果你使用 Papyrus、Trajan、Brush Script 或 Comic Sans，你就会被扣分。这些都是很糟糕的字体。选一个我不会讨厌的、朴素、简单的字体。这是要求的一部分。我说的就是你，Papyrus。

### [02:02] Daniel Walter Scott
And then what I want you to do is just take a screenshot. Um, I'll show you how to export frames and stuff properly later on, but it's actually just easier at the moment to go into Figma and open up your project, okay, and just take a screenshot. On a Mac, it's Command + Shift + 4, okay, and you can just drag a box around it, and on your desktop, you'll probably have a screenshot. On a PC, it's slightly different, you'd use Print Screen and then you paste it somewhere.
然后我希望你做的就是截个图。嗯，我稍后会教你们如何正确地导出画框之类的东西，但目前更简单的方法是直接进入 Figma，打开你的项目，然后截个图。在 Mac 上，快捷键是 Command + Shift + 4，然后你可以拖出一个选框。在你的桌面上就会出现截图。在 PC 上有点不同，你需要用 Print Screen 键，然后把它粘贴到某个地方。

### [02:31] Daniel Walter Scott
Just Google "how to take a screenshot". You're allowed to take a photo with your phone. Either way, do that and then upload it to either the projects or assignments. It depends on the website you're on, you'll have a look, there'll be a way to kind of submit it either as an assignment or a discussion or a project. Once you've done that, I will see you in the next video. Is that big homework? I don't know. It doesn't take too long. Uh, but it's good. We're going to practice our tools, our techniques, and we're going to get better together, but we need our wireframe. All right, I'll see you in the next video.
直接 Google 搜索“如何截图”。你也可以用手机拍照。不管用哪种方式，完成后把它上传到项目区或作业区。这取决于你正在使用的网站平台，你看一下，会有提交的方式，可能是作为作业、讨论或者一个项目。完成之后，我们下个视频见。这个作业量大吗？我不知道。应该花不了太长时间。嗯，但这是很好的练习。我们要练习我们的工具、我们的技巧，我们会一起进步，但我们需要先完成我们的线框图。好的，下个视频见。

## 重点整理（第一人称视角）
我从这个视频中学到了这次课堂项目的具体要求。我的任务是使用 Figma 创建一个包含四个页面的线框图（Wireframe）。

1.  **项目内容**：我要创建一个电子商务网站的线框图，它需要包含四个核心页面：
    *   主页/营销页 (Homepage/Marketing Page)
    *   产品详情页 (Product Details)
    *   结算页 (Checkout)
    *   确认页 (Confirmation)
2.  **设计要求**：我需要尽量模仿讲师提供的布局，这样便于后续课程的学习。我可以自定义颜色和字体，但讲师特别强调不要使用 Papyrus, Trajan, Brush Script, 或 Comic Sans 这些字体。
3.  **资源文件**：所有的项目要求、参考图片（`Wireframe Example.png`）和 Figma 模板文件（`Wireframe Example.fig`）都可以在课程的“Exercise Files”中找到。
4.  **提交方式**：完成线框图后，我需要对我的作品进行截图，然后根据课程平台的要求，将其上传到指定的项目区或作业区。

这个项目是我练习 Figma 基础操作和理解用户流程的好机会。

## 关键术语和人物
- **Wireframe (线框图)**：一种低保真度的设计原型，用于展示产品的基本结构、布局和核心功能，不包含详细的视觉设计元素。
- **Figma**：一款基于云端的协作式 UI/UX 设计工具，广泛用于界面设计和原型制作。
- **Task Flow (任务流程)**：描述用户为了完成特定目标而在一系列界面上所执行的步骤顺序。
- **Persona (用户画像)**：基于用户研究创建的虚拟用户角色，用于在设计过程中代表目标用户群体。
- **Brief (项目简介)**：一份概述项目目标、范围、目标受众和关键要求的文件。
- **Daniel Walter Scott**：本课程的讲师。

## 图像补充信息
视频中展示了项目最终需要完成的四个线框图页面，具体布局如下：
- **Homepage (主页)**：顶部是 Logo 和汉堡菜单图标，主体部分是一个大的图片占位符（Product Shot），下方是醒目的营销标语（"This is our marketing message."），以及两个行动号召按钮（"Buy Now" 和 "Learn More"）。
- **Product Details (产品详情页)**：顶部结构与主页相同。页面内容包括一个产品图片占位符、产品名称、价格、描述，以及三个并列的特性/优点介绍（Feature/Benefit），每个介绍都配有一个小的图片占位符。
- **Checkout (结算页)**：页面标题为 "Check out"。包含一个订单摘要（产品名称、运费、总计），以及用于输入电子邮件、信用卡信息（卡号、有效期、CVC）的表单字段，最后是一个 "Purchase" 按钮。
- **Confirmation (确认页)**：一个简单的成功页面，显示 "Congratulations!" 和 "Your order is on its way."，并用一个大箭头图形来增强视觉引导。