# 工作流操作手册 (SOP): 《交互产品综合创作》课程 V9.2

**版本: 2.0**

**日期: 2025-08-30**

**制定者: John (Product Manager)**

## **1. 概述与核心原则 (Overview & Core Principles)**

本文档是《交互产品综合创作》课程内容自动化生产流程的**唯一标准操作规程 (SOP)**。所有团队成员（包括教师和BMAD智能体）都必须严格遵循本手册定义的流程。

本工作流（V9版）基于以下核心原则设计：

- **人机分离**: 教师负责战略决策与创意输入；AI代理负责战术执行与流程自动化。
    
- **动态策展**: 通过独立的“资源策展”流程，持续地将原始素材转化为结构化的知识资产。
    
- **数据驱动**: AI的核心任务输入是一个平台无关的`.csv`文件，确保了指令的精确性和流程的健壮性。
    
- **强制深度阅读**: 整个系统的设计目标是为了确保AI代理能够深入阅读所有必要的教学素材，以产出高质量、细节丰富的教学内容。
    
- **Story作为执行契约**: 每周的生产任务被封装在结构化的“故事(Story)”文档中，该文档是SM、分析师、开发者和PO之间协作的“共同语言”和“契约”。
    

## **2. 角色与职责 (Roles & Responsibilities)**

|   |   |   |
|---|---|---|
||||
|**角色**|**BMAD成员**|**核心职责**|
|**总指挥 (Commander)**|**教师 (您)**|1. **创作**: 在`src/00_INBOX/`中添加原始教学素材。<br>2. **决策**: 监控仪表盘，决定何时触发“资源策展”任务。<br>3. **发布**: 在每周开始前，从仪表盘导出当周的`.csv`任务文件。<br>4. **指令**: 根据每个产出物末尾的“Handoff协议”，调用相应AI代理执行下一步。|
|**Scrum Master**|**SM**|**【新增】** 负责使用`TPL_Story.md`模板创建每周的“双子Story”，并从`prd.md`和`architecture.md`中提取所有必要的技术上下文填充到Story的“开发者笔记”中。|
|**策展分析师 (Curation Analyst)**|**Mary**|接收总指挥指令，自动为`INBOX`中的笔记生成YAML属性头（`tldr`, `week_num`等）并将其归档。|
|**内容生产分析师 (Content Production Analyst)**|**Mary**|接收`.csv`任务文件和“内容生产Story”，深度阅读所有指定的源文件，撰写详尽的`Week_XX.md`教学单元草稿。|
|**产品负责人 (Product Owner)**|**Sarah**|审核`Week_XX.md`草稿的质量，特别是验证其是否包含了源文件中的关键细节，是流程中的“质量守门员”。|
|**开发者 (Developer)**|**Developer**|接收通过审核的`Week_XX.md`和“幻灯片制作Story”，将其转化为最终的`.marpit.md`幻灯片，并更新Story中的执行记录。|

## **3. 关键产出物与数据规范 (Key Artifacts & Data Specs)**

### **3.1 标准化笔记属性 (YAML Frontmatter)**

所有位于`/src/`目录下的`.md`文件必须包含以下属性：

|   |   |   |
|---|---|---|
||||
|**属性名**|**数据类型**|**描述**|
|`week_num`|Number|笔记所属的周次。|
|`epic_num`|Number|笔记所属的史诗编号。|
|`sequence`|Number|在同一周内的处理顺序。|
|`type`|Text|素材类型 (如 `理论视频`, `补充笔记`)。|
|`status`|Text|策展状态 (`draft`, `ready`, `archived`)。|
|`tldr`|Text|由“策展分析师”生成的笔记核心摘要。|

### **3.2 `00_RESOURCE_DASHBOARD.md` (教师仪表盘)**

这是教师的管理中心，必须包含以下两个Bases视图的实现代码：

**A. 策展视图 (Curation View) - 代码实现**

```
views:
  - type: table
    name: "策展收件箱 (Curation INBOX)"
    filters:
      - file.inFolder("src/00_INBOX/")
```

**B. AI任务导出视图 (AI Task Export View) - 代码实现 (以第一周为例)**

```
properties:
  week_num:
    type: number
  sequence:
    type: number
  tldr:
    type: text
  file.path:
    type: text
  file.name:
    type: text
views:
  - type: table
    name: "Week 1 Export View"
    filters:
      and:
        - week_num == 1
        - status == "ready"
    order:
      - sequence
```

### **3.3 `RESOURCE_MAP_WXX.csv` (AI任务指令书)**

从Bases导出的、交付给“内容生产分析师”的文件。格式如下：

```
"week_num","sequence","tldr","file.path","file.name"
1,1,"核心摘要...","src/videos/figma-essentials/vid-figma-001.md","vid-figma-001.md"
...
```

### **3.4 【新增】 Story Document (敏捷故事文档)**

每周的“内容生产”和“幻灯片制作”任务都必须通过一个标准化的Story文档进行驱动。该文档由SM使用`/templates/TPL_Story.md`模板创建，是任务执行的唯一事实来源。它包含了状态、验收标准、技术上下文和执行记录。

## **4. 标准操作流程 (Standard Operating Procedures)**

### **流程 A: 资源策展 (按需维护)**

1. **触发**: 教师在`src/00_INBOX/`中添加了新的笔记，并决定进行整理。
    
2. **指令**: 教师调用**策展分析师(Mary)**，指令其对`src/00_INBOX/`执行“资源策展”任务。
    
3. **执行**: Mary扫描`INBOX`，为每个笔记生成YAML属性，与教师确认后，将属性写入文件，并将文件移动到`/src/`下的适当子目录。
    
4. **完成**: `INBOX`被清空，`00_RESOURCE_DASHBOARD.md`中的视图自动更新。
    

### **流程 B: 教学单元生成 (每周核心)**

1. **触发**: 新的一周开始。
    
2. **指令 (教师)**: 教师打开`00_RESOURCE_DASHBOARD.md`，导出当周的`RESOURCE_MAP_WXX.csv`文件。
    
3. **指令 (教师 -> SM)**: 教师通知**SM代理**当周任务可以启动。
    
4. **执行 (SM)**: SM代理检查到`.csv`文件存在，**使用`TPL_Story.md`模板创建“内容生产Story”**。它将PRD中的验收标准和Architecture中的相关技术上下文填充到Story中，然后指派给**内容生产分析师(Mary)**。
    
5. **执行 (Analyst Mary)**: Mary接收Story和`.csv`文件，**深度阅读**所有指定的`file.path`全文，撰写`Week_XX.md`草稿。完成后，**更新Story状态为`Review`**，并在文件末尾附上**指向PO的Handoff指令**。
    
6. **指令 (教师 -> PO)**: 教师根据Handoff指令，调用**产品负责人(Sarah)**进行审核。
    
7. **执行 (PO Sarah)**: Sarah审核`Week_XX.md`，并在Story的“QA结果”部分留下反馈。审核通过后，她**更新Story状态为`Done`**，并更新`Week_XX.md`文件末尾的Handoff指令，**使其指向Developer**。若不通过，则打回给Mary。
    

### **流程 C: 幻灯片制作 (每周核心)**

1. **触发**: `Week_XX.md`通过PO审核。
    
2. **指令 (教师 -> SM/Dev)**: 教师根据`Week_XX.md`末尾的Handoff指令，通知SM为**Developer**创建“幻灯片制作Story”。
    
3. **执行 (SM)**: SM创建Story，指派给Developer。
    
4. **执行 (Developer)**: Developer接收Story和`Week_XX.md`，生成`Week_XX.marpit.md`幻灯片。完成后，**更新Story状态为`Done`**，并在相关日志或Story评论中附上Handoff指令，宣告本周生产任务结束。
    

## **5. 【新增】Story生命周期管理 (Story Lifecycle Management)**

所有Story都遵循以下状态流转，确保任务进程清晰可追溯。

1. **Draft (草稿)**: 由SM创建时的初始状态。
    
2. **Approved (已批准)**: SM完成填充并指派给执行者（Analyst或Developer）。
    
3. **InProgress (进行中)**: 执行者开始处理任务。
    
4. **Review (审核中)**: 执行者完成任务并提交给PO进行审核。
    
5. **Done (已完成)**: PO审核通过，任务关闭。
    

每个BMAD成员在完成自己的环节后，都有责任更新Story文档中的相应状态和内容（如执行记录、QA结果）。

## **6. 交接指令协议 (Handoff Protocol)**

所有由AI代理生成的、需要下一步动作的文档，**必须**在文件末尾包含一个`Handoff`部分，其标准格式如下：

```
---
### **Handoff Protocol v1.0**
- **本阶段任务已完成**: [对已完成任务的简要描述]
- **产出物**: [指向本次产出的核心文件名，如 `Week_01.md`]
- **下一步状态**: [描述流程的下一个逻辑状态，如 `等待PO审核`]
- **下一步执行者**: [明确指定下一个BMAD成员的角色和名字，如 `Sarah (Product Owner)`]
- **教师指令**:
  > [提供给教师的、清晰的、可复制粘贴的下一步操作指令和建议的BMAD命令]
```

## **附录 A: 教师操作指南 (Commander's Playbook)**

本指南为您（总指挥）提供清晰的、场景化的行动指令。

### **场景一：我写了一批新笔记，该做什么？**

1. **您的行动**: 将所有新笔记文件放入`/src/00_INBOX/`目录。
    
2. **检查仪表盘**: 打开`00_RESOURCE_DASHBOARD.md`，在“策展收件箱”视图中确认您的文件已出现。
    
3. **下达指令**: 当您准备好整理时，调用Analyst Mary。
    
    > **建议命令**: `*agent analyst` 然后 `请为我执行“资源策展”任务，处理INBOX中的所有新笔记。`
    

### **场景二：如何启动新一周的内容生产？**

1. **您的行动**: 打开`00_RESOURCE_DASHBOARD.md`，切换到您想启动的周次（例如“Week 3 Export View”）。
    
2. **发布资源**: 点击视图右上角的菜单，选择“**Export CSV**”。将文件保存为`RESOURCE_MAP_W03.csv`（周次对应）。
    
3. **下达指令**: 确认CSV文件已保存后，调用SM代理。
    
    > **建议命令**: `*agent sm` 然后 `请根据已发布的CSV文件，为第三周创建“内容生产Story”。`
    

### **场景三：AI完成了一个任务，我该做什么？**

1. **您的行动**: 打开AI交付的文档（例如`Week_03.md`）或对应的Story文档。
    
2. **阅读交接协议**: 滚动到文件最下方，阅读“Handoff Protocol”部分。
    
3. **下达指令**: 复制“教师指令”中建议的命令，调用下一个AI代理执行任务。
    

## **附录 B: 验收标准 (AC) 编写指南**

为确保“内容生产分析师”进行深度阅读，SM代理在创建其Story时，必须加入一个“细节验证AC”。

**原则**: 该AC应提出一个**只有在阅读了源文件全文后才能回答的问题或完成的任务**。

**范例一 (基于内容)**:

> **AC-细节验证**: 草稿中对“画框与组的区别”的解释，必须包含源文件`[[vid-figma-015-frames-vs-groups]]`正文中提到的关于“剪裁蒙版(clipping mask)”行为的具体差异。

**范例二 (基于结构)**:

> **AC-细节验证**: 草稿必须根据源文件`[[vid-spline-005-states-events]]`中的步骤，创建一个关于“悬停显示价格”交互的完整操作指引。

## **附录 C: 错误处理与回退流程**

- **PO审核打回**: 如果PO Sarah审核不通过`Week_XX.md`，她会将对应的Story状态重新标记为`InProgress`并指派回Analyst Mary，同时在Story的“QA结果”部分附上具体的修改意见。Mary必须完成修改后重新提交审核。
    
- **CSV文件缺失**: 如果SM代理在启动周度任务时未找到对应的`RESOURCE_MAP_WXX.csv`文件，它将暂停创建Story，并向教师（您）发出通知，请求您先导出并发布该周的资源地图。