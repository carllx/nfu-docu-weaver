# 架构文档：《交互产品综合创作》课程知识库

**版本: 3.2 (Story集成版)**

**日期: 2025-08-30**

**架构师 (Architect): Winston**

## **1. 简介 (Introduction)**

本架构文档依据产品需求文档 `prd_v3.0.md` 进行设计，旨在为《交互产品综合创作》课程构建一个专供教师使用的、基于Obsidian的、支持V9版自动化工作流的知识库系统。

此架构的核心设计哲学是**“动态策展”**与**“人机分离”**：

- **人类友好**: 为教师提供一个直观、低维护的教学资源管理环境。
    
- **AI友好**: 为BMAD智能体提供清晰、结构化、普遍兼容的数据输入，以确保自动化流程的可靠性和产出质量。
    

本文档将定义知识库的目录结构、核心数据模板、以及关键文件的技术规范。

## **2. 高层架构 (High-Level Architecture)**

系统整体架构由以下几个核心部分构成，确保了职责分离和流程顺畅：

1. **原始素材层 (Source Layer - `/src/`)**: 所有教学素材的唯一入口和存储区，采用“类型优先”的扁平化结构管理。
    
2. **动态管理层 (Management Layer)**: 以`00_RESOURCE_DASHBOARD.md`为核心，利用Obsidian Bases插件为教师提供一个动态的、可视化的资源管理仪表盘。
    
3. **数据交换层 (Data Exchange Layer)**: 通过从Bases导出的`.csv`文件，为外部AI代理提供标准化的、平台无关的任务指令书。
    
4. **【更新】敏捷执行层 (Agile Execution Layer)**: 以标准化的**Story文档**为核心，将每周的生产任务具体化为包含完整技术上下文、可独立执行的“任务契约”。
    
5. **内容生产层 (Production Layer)**: 由AI代理根据Story文档生成的中间产物（如`Week_XX.md`）和最终产出物（如`Week_XX.marpit.md`）。
    
6. **模板与规范层 (Templates & Standards)**: 定义所有产出物必须遵循的结构化模板。
    

## **3. 详细架构设计 (Detailed Architecture)**

### **3.1 Obsidian Vault 目录结构**

本结构采纳了“类型优先，主题为辅”的混合扁平化设计，以兼顾组织清晰性与Obsidian链接的稳定性。

```
/课程知识库/
├── 00_RESOURCE_DASHBOARD.md      # [核心] 教师的动态管理仪表盘
├── docs/                         # 核心项目文档
│   ├── prd.md                    # 产品需求文档 v3.0
│   ├── architecture.md           # 本架构文档 v3.2
│   └── SOP-BMAD-Workflow.md      # [核心] 工作流操作手册
│   └── COURSE_SYLLABUS.md        # 面向学生的课程大纲
├── src/                          # 原始素材层
│   ├── 00_INBOX/                 # 所有新笔记的“收件箱”
│   ├── videos/
│   │   ├── figma-essentials/     # Figma系列视频字幕稿
│   │   └── spline-essentials/    # Spline系列视频字幕稿
│   │   └── ...
│   ├── notes/                    # 所有零散的补充笔记
│   └── assets/                   # 所有非文本资源 (e.g., .fig, .spline)
├── content/                      # 内容生产层
│   ├── weekly-units/             # AI生成的周度教学单元
│   │   ├── Week_01.md
│   │   └── ...
│   └── slides/                   # AI生成的最终幻灯片
│       ├── Week_01.marpit.md
│       └── ...
├── stories/                      # 【新增】敏捷执行层 - 存放所有Story文档
│   ├── W01_Analyst_UnitGeneration.md
│   ├── W01_Developer_SlideCreation.md
│   └── ...
└── templates/                    # 模板与规范层
    ├── TPL_Weekly_Unit.md
    ├── TPL_Marpit_Slide.md
    └── TPL_Story.md              # 【新增】标准Story模板

```

### **3.2 核心数据与文件规范**

#### **A. 标准化笔记属性 (YAML Frontmatter)**

所有位于`/src/`目录下的`.md`文件**必须**包含以下YAML属性头。详细定义请参见`SOP-BMAD-Workflow.md`。

```
---
week_num: 1
epic_num: 1
sequence: 1
type: "理论视频"
status: "ready"
tldr: "本笔记的核心摘要，由策展分析师生成。"
---
```

#### **B. `00_RESOURCE_DASHBOARD.md` (教师仪表盘)**

该文件是教师与知识库交互的核心界面。它**必须**包含以下两个Bases视图的**可复制粘贴的完整代码实现**，以确保开箱即用。

- **视图一：策展视图 (Curation View)**
    
    - **功能**: 监控`src/00_INBOX/`目录，自动列出所有待处理的新笔记。
        
    - **代码实现**:
        
        ```
        views:
          - type: table
            name: "策展收件箱 (Curation INBOX)"
            filters:
              - file.inFolder("src/00_INBOX/")
        ```
        
- **视图二：AI任务导出视图 (AI Task Export View)**
    
    - **功能**: 为特定周次生成一个包含所有`ready`状态资源的表格视图，用于**导出为CSV文件**。
        
    - **代码实现 (以第一周为例)**:
        
        ```
        properties:
          week_num:
            type: number
          sequence:
            type: number
          tldr:
            type: text
          file.path:
            type: text
          file.name:
            type: text
        views:
          - type: table
            name: "Week 1 Export View"
            filters:
              and:
                - week_num == 1
                - status == "ready"
            order:
              - sequence
        ```
        

### **3.3 核心内容模板 (附完整初始代码)**

#### **A. `TPL_Weekly_Unit.md` (周度单元模板)**

由“内容生产分析师”填充的结构化草稿模板。

```
---
week_num: {{week_num}}
epic_num: {{epic_num}}
title: "{{week_title}}"
prd_version: {{prd_version}}
status: "draft" 
context_checksum: "{{csv_file_version}}"
---

# Week {{week_num}}: {{week_title}}

## 1. 本周目标与验收标准
![[prd.md#^{{week_block_id}}]]

## 2. 核心概念详解
> 由分析师根据所有源文件全文综合撰写

## 3. 实践环节指引
> 由分析师根据所有源文件全文综合撰写

---
### **Handoff Protocol v1.0**
- **本阶段任务已完成**: `Week_XX.md` 草稿已生成。
- **下一步状态**: **等待PO审核**
- **下一步执行者**: **Sarah (Product Owner)**
- **教师指令**: > ...
```

#### **B. `TPL_Marpit_Slide.md` (幻灯片模板)**

由“开发者”使用的最终产出物模板。

```
---
marp: true
theme: uncover
class: invert
---

# **Week {{week_num}}: {{week_title}}**

---

## 本周目标
> 根据 `Week_XX.md` 的内容生成

---

<!-- 更多幻灯片页面 -->
```

#### **C. 【新增】`TPL_Story.md` (敏捷故事模板)**

由SM代理使用的、用于创建每周生产任务的标准化模板。

```
---
status: "Draft"
assignee: "{{assignee_name}}"
epic: "{{epic_num}}"
week: "{{week_num}}"
---

# Story: Week {{week_num}} - {{task_description}}

## 1. 用户故事 (User Story)
> **作为** 一名 {{role}},
> **我希望** {{action}},
> **以便** {{benefit}}.

## 2. 验收标准 (Acceptance Criteria)
![[prd.md#^{{week_ac_block_id}}]]
- **【细节验证AC】**: {{specific_detail_ac}}

## 3. 开发者笔记 (Developer Notes)
> **核心指令**: 必须严格遵循以下上下文和规范完成任务。
>
> **相关架构规范**:
> - ... (从architecture.md中提取的相关规范)
>
> **相关SOP流程**:
> - ... (从SOP.md中提取的相关流程)

## 4. 任务清单 (Tasks / Subtasks)
- [ ] 任务一
- [ ] 任务二

## 5. 执行记录 (Execution Record)
> 本部分由执行者在任务完成后填写。

- **执行者**:
- **产出物链接**:
- **完成时间**:

## 6. QA结果 (QA Results)
> 本部分由PO (Sarah)在审核后填写。

- **审核结果**: (通过/打回)
- **审核意见**:

---
### **Handoff Protocol v1.0**
- **本阶段任务已完成**: Story已创建/执行/审核
- **下一步状态**: 
- **下一步执行者**:
- **教师指令**: > ...
```

## **4. 架构决策与理由 (Architectural Decisions & Rationale)**

- **决策一：采用Bases导出CSV作为人机接口**
    
    - **理由**: 完美解决了“外部AI无法渲染Bases视图”的技术壁垒。CSV是通用、稳定、Token高效的数据交换格式，同时保留了Bases作为教师强大管理工具的内部价值。
        
- **决策二：采用“收件箱+类型化”的扁平目录结构**
    
    - **理由**: 既为大型视频系列提供了独立的组织空间，又通过扁平的`notes`文件夹和`INBOX`机制，极大地简化了日常维护，符合Obsidian的最佳实践。
        
- **决策三：在模板和所有交付物中强制嵌入“Handoff协议”**
    
    - **理由**: 将隐性的工作流步骤显性化、标准化。这为教师提供了清晰的操作指引，也为未来更高阶的流程自动化奠定了基础。
        
- **决策四：采用Obsidian块引用链接PRD**
    
    - **理由**: 在内容模板中使用 `![[prd.md#^...]]` 形式的块引用，确保了教学目标始终与PRD的最新版本保持动态同步，强化了PRD作为“唯一事实来源”的地位。
        
- **决策五：【新增】引入Story文档作为核心执行单元**
    
    - **理由**: 将高层的产品需求（PRD）与底层的执行任务解耦。Story文档作为一个独立的、包含完整技术上下文的“任务契约”，极大地提高了AI代理执行任务的精确性和可靠性，并使整个敏捷流程变得透明和可追溯。
        

## **5. 实施与下一步 (Implementation & Next Steps)**

本架构文档为项目的技术实现提供了明确的蓝图。

1. **产品负责人 (PO) Sarah**: 负责监督本架构的实施，确保所有文件和目录的创建都遵循此规范。
    
2. **移交SOP最终确认**: 本架构文档将作为核心输入，用于对**《工作流操作手册》(SOP)**进行最终的审查和更新，确保SOP中的所有流程细节与本架构完全对齐。
    
3. **初始化Vault**: 根据本架构，在Obsidian中创建所有必要的文件夹和模板文件。
    

### **Handoff Protocol v1.0**

- **本阶段任务已完成**: `architecture.md` v3.2 已生成。
    
- **产出物**: `architecture.md`
    
- **下一步状态**: **等待SOP最终版确认 (Pending Final SOP Confirmation)**
    
- **下一步执行者**: **John (Product Manager)**
    
- **教师指令**:
    
    > 请调用 **PM (John)**，要求他基于本架构文档的最终版 (`v3.2`)，对 `SOP-BMAD-Workflow.md` 进行最终的审查和更新，确保SOP中的所有流程细节与本架构完全对齐。